
package com.example.weighttracker;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/** Register screen to create a first-time username/password. */
public class RegisterActivity extends AppCompatActivity {

    private UserRepository users;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        users = new UserRepository(this);

        EditText etUser = findViewById(R.id.etNewUsername);
        EditText etPass = findViewById(R.id.etNewPassword);
        Button btn = findViewById(R.id.btnCreateAccount);

        btn.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString();
            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }
            if (users.register(u, p)) {
                Toast.makeText(this, "Account created. Please log in.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
