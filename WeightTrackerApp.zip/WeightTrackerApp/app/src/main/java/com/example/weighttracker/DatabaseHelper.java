
package com.example.weighttracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * SQLiteOpenHelper that creates two tables:
 *  - users(username TEXT PRIMARY KEY, password TEXT)
 *  - weights(id INTEGER PK, date TEXT, weight REAL, notes TEXT, username TEXT FK)
 *
 * NOTE: Passwords are stored in plain text for academic demo purposes only.
 * Do NOT do this in production—use proper hashing.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "weighttracker.db";
    public static final int DB_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    public static final String TABLE_WEIGHTS = "weights";
    public static final String COL_ID = "id";
    public static final String COL_DATE = "date";
    public static final String COL_WEIGHT = "weight";
    public static final String COL_NOTES = "notes";
    public static final String COL_USER = "user";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DATE + " TEXT NOT NULL, " +
                COL_WEIGHT + " REAL NOT NULL, " +
                COL_NOTES + " TEXT, " +
                COL_USER + " TEXT NOT NULL, " +
                "FOREIGN KEY(" + COL_USER + ") REFERENCES " + TABLE_USERS + "(" + COL_USERNAME + "))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
}
