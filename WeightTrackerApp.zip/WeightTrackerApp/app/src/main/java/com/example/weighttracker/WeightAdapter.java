
package com.example.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/** RecyclerView adapter that displays entries in a grid (handled by GridLayoutManager). */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.VH> {

    public interface OnItemClick {
        void onClick(WeightEntry entry);
        void onLongClick(WeightEntry entry);
    }

    private final List<WeightEntry> data = new ArrayList<>();
    private final OnItemClick listener;

    public WeightAdapter(OnItemClick l) { this.listener = l; }

    public void setData(List<WeightEntry> entries) {
        data.clear();
        data.addAll(entries);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        WeightEntry e = data.get(position);
        holder.tvDate.setText(e.date);
        holder.tvWeight.setText(String.format("%.1f lbs", e.weight));
        holder.tvNotes.setText(e.notes == null ? "" : e.notes);
        holder.itemView.setOnClickListener(v -> listener.onClick(e));
        holder.itemView.setOnLongClickListener(v -> { listener.onLongClick(e); return true; });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight, tvNotes;
        VH(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            tvNotes = itemView.findViewById(R.id.tvNotes);
        }
    }
}
