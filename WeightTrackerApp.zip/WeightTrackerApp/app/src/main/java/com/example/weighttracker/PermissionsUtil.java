
package com.example.weighttracker;

import android.app.Activity;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionsUtil {
    public static final int REQ_SMS = 42;
    public static boolean hasSmsPermission(Activity a) {
        return ContextCompat.checkSelfPermission(a, android.Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }
    public static void requestSms(Activity a) {
        ActivityCompat.requestPermissions(a,
                new String[]{android.Manifest.permission.SEND_SMS}, REQ_SMS);
    }
}
