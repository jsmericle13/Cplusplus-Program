
package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/** Repository for CRUD on weights table. */
public class WeightRepository {
    private final DatabaseHelper helper;

    public WeightRepository(Context ctx) {
        this.helper = new DatabaseHelper(ctx);
    }

    public long create(String user, String date, double weight, String notes) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COL_USER, user);
        cv.put(DatabaseHelper.COL_DATE, date);
        cv.put(DatabaseHelper.COL_WEIGHT, weight);
        cv.put(DatabaseHelper.COL_NOTES, notes);
        return db.insert(DatabaseHelper.TABLE_WEIGHTS, null, cv);
    }

    public boolean update(long id, String date, double weight, String notes) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COL_DATE, date);
        cv.put(DatabaseHelper.COL_WEIGHT, weight);
        cv.put(DatabaseHelper.COL_NOTES, notes);
        int rows = db.update(DatabaseHelper.TABLE_WEIGHTS, cv, DatabaseHelper.COL_ID + "=?",
                new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean delete(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        int rows = db.delete(DatabaseHelper.TABLE_WEIGHTS, DatabaseHelper.COL_ID + "=?",
                new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public List<WeightEntry> listForUser(String user) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DatabaseHelper.TABLE_WEIGHTS,
                null,
                DatabaseHelper.COL_USER + "=?",
                new String[]{user},
                null, null, DatabaseHelper.COL_DATE + " DESC");
        List<WeightEntry> out = new ArrayList<>();
        while (c.moveToNext()) {
            long id = c.getLong(c.getColumnIndexOrThrow(DatabaseHelper.COL_ID));
            String date = c.getString(c.getColumnIndexOrThrow(DatabaseHelper.COL_DATE));
            double w = c.getDouble(c.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT));
            String notes = c.getString(c.getColumnIndexOrThrow(DatabaseHelper.COL_NOTES));
            out.add(new WeightEntry(id, date, w, notes, user));
        }
        c.close();
        return out;
    }
}
