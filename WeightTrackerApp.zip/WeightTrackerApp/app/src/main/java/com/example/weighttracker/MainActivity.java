
package com.example.weighttracker;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Main screen: shows a grid of weight entries and allows CRUD.
 * Also handles SMS permission request and sending a simple goal-reached alert.
 */
public class MainActivity extends AppCompatActivity {

    private String username;
    private WeightRepository repo;
    private WeightAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = getIntent().getStringExtra("username");
        if (username == null) username = "guest";

        repo = new WeightRepository(this);
        adapter = new WeightAdapter(new WeightAdapter.OnItemClick() {
            @Override
            public void onClick(WeightEntry entry) { showUpdateDialog(entry); }
            @Override
            public void onLongClick(WeightEntry entry) {
                if (repo.delete(entry.id)) {
                    Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                    refresh();
                }
            }
        });

        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new GridLayoutManager(this, 2));
        rv.setAdapter(adapter);
        refresh();

        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v -> showCreateDialog());

        Button btnSms = findViewById(R.id.btnSendSms);
        btnSms.setOnClickListener(v -> {
            if (PermissionsUtil.hasSmsPermission(this)) {
                sendGoalSms();
            } else {
                PermissionsUtil.requestSms(this);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionsUtil.REQ_SMS) {
            if (PermissionsUtil.hasSmsPermission(this)) {
                sendGoalSms();
            } else {
                Toast.makeText(this, "SMS permission denied. App continues without SMS.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void refresh() {
        List<WeightEntry> list = repo.listForUser(username);
        adapter.setData(list);
    }

    private void showCreateDialog() {
        EntryForm form = new EntryForm(this);
        new AlertDialog.Builder(this)
                .setTitle("Add Weight")
                .setView(form.container)
                .setPositiveButton("Save", (d, w) -> {
                    String date = form.date.getText().toString().trim();
                    String weightStr = form.weight.getText().toString().trim();
                    String notes = form.notes.getText().toString().trim();
                    if (date.isEmpty() || weightStr.isEmpty()) {
                        Toast.makeText(this, "Date and weight are required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    double val = Double.parseDouble(weightStr);
                    repo.create(username, date, val, notes);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showUpdateDialog(WeightEntry entry) {
        EntryForm form = new EntryForm(this);
        form.date.setText(entry.date);
        form.weight.setText(String.valueOf(entry.weight));
        form.notes.setText(entry.notes);
        new AlertDialog.Builder(this)
                .setTitle("Update Weight")
                .setView(form.container)
                .setPositiveButton("Update", (d, w) -> {
                    String date = form.date.getText().toString().trim();
                    String weightStr = form.weight.getText().toString().trim();
                    String notes = form.notes.getText().toString().trim();
                    if (date.isEmpty() || weightStr.isEmpty()) {
                        Toast.makeText(this, "Date and weight are required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    double val = Double.parseDouble(weightStr);
                    if (repo.update(entry.id, date, val, notes)) {
                        refresh();
                    }
                })
                .setNeutralButton("Delete", (d, w) -> {
                    if (repo.delete(entry.id)) refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** After permission grant, prompt for phone & goal then send an SMS alert. */
    private void sendGoalSms() {
        EntryFormPhoneGoal form = new EntryFormPhoneGoal(this);
        new AlertDialog.Builder(this)
                .setTitle("Send Goal Alert")
                .setView(form.container)
                .setPositiveButton("Send", (d, w) -> {
                    String phone = form.phone.getText().toString().trim();
                    String goalStr = form.goal.getText().toString().trim();
                    if (phone.isEmpty() || goalStr.isEmpty()) {
                        Toast.makeText(this, "Phone and goal weight required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    double goal = Double.parseDouble(goalStr);
                    // Check most recent entry and send message
                    List<WeightEntry> list = repo.listForUser(username);
                    if (!list.isEmpty() && list.get(0).weight <= goal) {
                        SmsUtil.send(phone, "Congrats " + username + "! Goal reached: " + list.get(0).weight + " lbs");
                        Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
                    } else {
                        SmsUtil.send(phone, "Update: Keep going, " + username + "! You're close to your goal.");
                        Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Small inline form builder to avoid separate XML for dialogs. */
    static class EntryForm {
        LinearLayout container;
        EditText date, weight, notes;
        EntryForm(AppCompatActivity a) {
            container = new LinearLayout(a);
            container.setOrientation(LinearLayout.VERTICAL);
            int pad = (int) (16 * a.getResources().getDisplayMetrics().density);
            container.setPadding(pad, pad, pad, pad);

            date = new EditText(a);
            date.setHint("Date (yyyy-MM-dd)");
            container.addView(date);

            weight = new EditText(a);
            weight.setHint("Weight (lbs)");
            weight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            container.addView(weight);

            notes = new EditText(a);
            notes.setHint("Notes");
            container.addView(notes);
        }
    }

    static class EntryFormPhoneGoal {
        LinearLayout container;
        EditText phone, goal;
        EntryFormPhoneGoal(AppCompatActivity a) {
            container = new LinearLayout(a);
            container.setOrientation(LinearLayout.VERTICAL);
            int pad = (int) (16 * a.getResources().getDisplayMetrics().density);
            container.setPadding(pad, pad, pad, pad);

            phone = new EditText(a);
            phone.setHint("Phone number");
            phone.setInputType(InputType.TYPE_CLASS_PHONE);
            container.addView(phone);

            goal = new EditText(a);
            goal.setHint("Goal weight (lbs)");
            goal.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            container.addView(goal);
        }
    }
}
