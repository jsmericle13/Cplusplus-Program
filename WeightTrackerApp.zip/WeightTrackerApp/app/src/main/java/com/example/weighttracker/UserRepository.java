
package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/** Simple repository for user auth. */
public class UserRepository {
    private final DatabaseHelper helper;

    public UserRepository(Context ctx) {
        this.helper = new DatabaseHelper(ctx);
    }

    /** Returns true if credentials match; false otherwise. */
    public boolean login(String username, String password) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.COL_USERNAME},
                DatabaseHelper.COL_USERNAME + "=? AND " + DatabaseHelper.COL_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    /** Creates a new user; returns false if username already exists. */
    public boolean register(String username, String password) {
        SQLiteDatabase db = helper.getWritableDatabase();
        // Check existing
        Cursor c = db.query(DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.COL_USERNAME},
                DatabaseHelper.COL_USERNAME + "=?",
                new String[]{username}, null, null, null);
        boolean exists = c.moveToFirst();
        c.close();
        if (exists) return false;

        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COL_USERNAME, username);
        cv.put(DatabaseHelper.COL_PASSWORD, password);
        long id = db.insert(DatabaseHelper.TABLE_USERS, null, cv);
        return id != -1;
    }
}
