
package com.example.weighttracker;

import android.telephony.SmsManager;

/** Tiny wrapper around SmsManager; assumes permission already granted. */
public class SmsUtil {
    public static void send(String phone, String message) {
        SmsManager sm = SmsManager.getDefault();
        sm.sendTextMessage(phone, null, message, null, null);
    }
}
