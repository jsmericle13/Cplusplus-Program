
package com.example.weighttracker;

/** POJO model for a weight entry. */
public class WeightEntry {
    public long id;
    public String date; // ISO string yyyy-MM-dd
    public double weight;
    public String notes;
    public String user;

    public WeightEntry(long id, String date, double weight, String notes, String user) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.notes = notes;
        this.user = user;
    }
}
