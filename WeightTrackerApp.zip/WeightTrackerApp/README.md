# Weight Tracker App (CS 360 Project Three)

This Android Studio project demonstrates:
- Login/Registration with SQLite (users table)
- Persistent SQLite database for daily weights (CRUD)
- Grid display via RecyclerView + GridLayoutManager
- Runtime SMS permission request and SMS alerts via `SmsManager`
- Clean, commented Java code and Material styling

## Open
1. Open Android Studio → **Open** → select this folder.
2. Let Gradle sync.
3. Run on an emulator (API 24+).

## Notes
- SMS requires runtime permission. If denied, the app still works without alerts.
- Passwords are stored in plain text for class demo only.
