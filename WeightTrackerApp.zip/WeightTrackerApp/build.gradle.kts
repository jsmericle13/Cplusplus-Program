plugins {
    id("com.android.application") version "8.5.0" apply false
}
