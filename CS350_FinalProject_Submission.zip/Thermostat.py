#!/usr/bin/env python3
"""
CS 350 Final Project - Smart Thermostat Prototype (Thermostat.py)

Per lab guide requirements:
- AHT20 sensor via I2C
- 2 LEDs indicate HEAT/COOL (fade when active; solid when temp at/over/under thresholds)
- 3 buttons:
  A) Toggle state machine: OFF -> HEAT -> COOL -> OFF
  B) Increase set point by 1°F
  C) Decrease set point by 1°F
- LCD (16x2) shows:
  Line 1: date/time
  Line 2: alternates between current temperature and (state + set point)
- UART outputs comma-delimited string every 30 seconds:
  state,current_temp,set_point

NOTE: Pin numbers below use BCM numbering. If your course template used different pins for the MODE
button or LEDs, change the constants at the top to match your wiring.
"""

import time
import threading
from datetime import datetime

from gpiozero import Button, PWMLED
import serial

# --- I2C sensor (AHT20) ---
try:
    import board
    import busio
    import adafruit_ahtx0
except Exception:
    board = busio = adafruit_ahtx0 = None

# --- LCD (common I2C 16x2) ---
# Many SNHU CS350 setups use an I2C backpack (PCF8574) around address 0x27.
# If your class used a different LCD library, swap this section to match.
try:
    from RPLCD.i2c import CharLCD
except Exception:
    CharLCD = None


# ---------------- Configuration (BCM pins) ----------------
# Buttons added in Final Project guide:
BTN_UP_PIN = 25     # increase set point (guide: breakout "25")
BTN_DOWN_PIN = 12   # decrease set point (guide: breakout "12")

# The MODE button (toggle OFF/HEAT/COOL) was part of the earlier circuit.
# If your template/lab uses a different GPIO, change it here.
BTN_MODE_PIN = 16   # <-- adjust if needed

# LED pins (change if your earlier labs used different GPIOs)
RED_LED_PIN = 5     # heat
BLUE_LED_PIN = 6    # cool

# UART settings
UART_PORT = "/dev/serial0"
UART_BAUD = 9600

# LCD settings
LCD_I2C_ADDR = 0x27
LCD_COLS = 16
LCD_ROWS = 2

# Thermostat settings
DEFAULT_SETPOINT_F = 72.0
MIN_SETPOINT_F = 50.0
MAX_SETPOINT_F = 90.0

# Timing
TEMP_READ_INTERVAL = 0.5
LCD_UPDATE_INTERVAL = 0.5
LCD_ALTERNATE_INTERVAL = 2.0
UART_INTERVAL = 30.0


class Mode:
    OFF = "off"
    HEAT = "heat"
    COOL = "cool"


class Thermostat:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.mode = Mode.OFF
        self.setpoint_f = DEFAULT_SETPOINT_F
        self.current_f = DEFAULT_SETPOINT_F

        # LEDs (PWM so we can fade)
        self.heat_led = PWMLED(RED_LED_PIN)
        self.cool_led = PWMLED(BLUE_LED_PIN)

        # Buttons (GPIOZero uses edge detection with callbacks)
        self.btn_mode = Button(BTN_MODE_PIN, pull_up=True, bounce_time=0.08)
        self.btn_up = Button(BTN_UP_PIN, pull_up=True, bounce_time=0.08)
        self.btn_down = Button(BTN_DOWN_PIN, pull_up=True, bounce_time=0.08)

        self.btn_mode.when_pressed = self._on_mode
        self.btn_up.when_pressed = self._on_up
        self.btn_down.when_pressed = self._on_down

        # UART
        self.uart = serial.Serial(
            port=UART_PORT,
            baudrate=UART_BAUD,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=1,
        )

        # I2C temp sensor
        self.sensor = None
        if board and busio and adafruit_ahtx0:
            i2c = busio.I2C(board.SCL, board.SDA)
            self.sensor = adafruit_ahtx0.AHTx0(i2c)

        # LCD
        self.lcd = None
        if CharLCD:
            # Common backpack is PCF8574; change if your address differs
            self.lcd = CharLCD("PCF8574", LCD_I2C_ADDR, cols=LCD_COLS, rows=LCD_ROWS)

        # internal variables
        self._fade_phase = 0.0
        self._show_current_line = True
        self._last_alternate = time.time()

    # ---------- Interrupt handlers ----------
    def _on_mode(self) -> None:
        with self._lock:
            if self.mode == Mode.OFF:
                self.mode = Mode.HEAT
            elif self.mode == Mode.HEAT:
                self.mode = Mode.COOL
            else:
                self.mode = Mode.OFF

    def _on_up(self) -> None:
        with self._lock:
            self.setpoint_f = min(MAX_SETPOINT_F, self.setpoint_f + 1.0)

    def _on_down(self) -> None:
        with self._lock:
            self.setpoint_f = max(MIN_SETPOINT_F, self.setpoint_f - 1.0)

    # ---------- I2C read ----------
    def _read_temp_f(self) -> float:
        if self.sensor is None:
            # Fallback if the library isn't available: keep last value
            return self.current_f
        c = float(self.sensor.temperature)
        return (c * 9.0 / 5.0) + 32.0

    # ---------- LED behavior (matches lab guide) ----------
    def _update_leds(self) -> None:
        with self._lock:
            mode = self.mode
            cur = self.current_f
            sp = self.setpoint_f

        # default off
        self.heat_led.value = 0.0
        self.cool_led.value = 0.0

        if mode == Mode.OFF:
            return

        # Fade wave 0..1..0
        self._fade_phase += 0.06
        if self._fade_phase > 2.0:
            self._fade_phase = 0.0
        fade = self._fade_phase if self._fade_phase <= 1.0 else (2.0 - self._fade_phase)

        if mode == Mode.HEAT:
            # A) If current < setpoint => fade red
            # B) If current >= setpoint => red solid on
            if cur < sp:
                self.heat_led.value = fade
            else:
                self.heat_led.value = 1.0

        elif mode == Mode.COOL:
            # A) If current > setpoint => fade blue
            # B) If current <= setpoint => blue solid on
            if cur > sp:
                self.cool_led.value = fade
            else:
                self.cool_led.value = 1.0

    # ---------- LCD ----------
    def _update_lcd(self) -> None:
        if self.lcd is None:
            return

        with self._lock:
            mode = self.mode
            cur = self.current_f
            sp = self.setpoint_f

        now = datetime.now()
        line1 = now.strftime("%m/%d %H:%M:%S")[:16]

        # alternate line2 between current temp and (state + setpoint)
        if time.time() - self._last_alternate >= LCD_ALTERNATE_INTERVAL:
            self._show_current_line = not self._show_current_line
            self._last_alternate = time.time()

        if self._show_current_line:
            line2 = f"Temp: {cur:0.1f}F"[:16]
        else:
            # ex: "heat set:72"
            line2 = f"{mode} set:{sp:0.0f}F"[:16]

        self.lcd.cursor_pos = (0, 0)
        self.lcd.write_string(line1.ljust(16))
        self.lcd.cursor_pos = (1, 0)
        self.lcd.write_string(line2.ljust(16))

    # ---------- UART ----------
    def _send_uart(self) -> None:
        with self._lock:
            msg = f"{self.mode},{self.current_f:0.1f},{self.setpoint_f:0.1f}\n"
        self.uart.write(msg.encode("utf-8"))

    def run(self) -> None:
        last_temp = 0.0
        last_lcd = 0.0
        last_uart = 0.0

        # clear display once
        if self.lcd:
            self.lcd.clear()

        try:
            while True:
                now = time.time()

                # Read temperature
                if now - last_temp >= TEMP_READ_INTERVAL:
                    temp_f = self._read_temp_f()
                    with self._lock:
                        self.current_f = temp_f
                    last_temp = now

                # State machine drives outputs
                self._update_leds()

                # LCD updates
                if now - last_lcd >= LCD_UPDATE_INTERVAL:
                    self._update_lcd()
                    last_lcd = now

                # UART output
                if now - last_uart >= UART_INTERVAL:
                    self._send_uart()
                    last_uart = now

                time.sleep(0.05)

        finally:
            self.heat_led.value = 0.0
            self.cool_led.value = 0.0
            try:
                self.uart.close()
            except Exception:
                pass
            if self.lcd:
                try:
                    self.lcd.clear()
                except Exception:
                    pass


if __name__ == "__main__":
    Thermostat().run()
