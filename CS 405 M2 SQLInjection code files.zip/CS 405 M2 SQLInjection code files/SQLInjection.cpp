// SQLInjection.cpp
// CS 405 Module Two - SQL Injection Activity
//
// This file demonstrates a SQL injection vulnerability and implements a defense
// inside run_query() for the specific attack pattern:
//      OR value=value;
// where value is a SQL literal (numeric or quoted string).
//
// NOTE: Keep sqlite3.c and sqlite3.h in the same folder.

#include <iostream>
#include <string>
#include <tuple>
#include <vector>
#include <regex>
#include <cctype>
#include <algorithm>

#include "sqlite3.h"

// DO NOT CHANGE
typedef std::tuple<std::string, std::string, std::string> user_record;
const std::string str_where = " where ";

// DO NOT CHANGE
static int callback(void* possible_vector, int argc, char** argv, char** azColName)
{
    if (possible_vector == NULL)
    {
        // no vector passed in, so just display the results
        for (int i = 0; i < argc; i++)
        {
            std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
        }
        std::cout << std::endl;
    }
    else
    {
        std::vector<user_record>* rows =
            static_cast<std::vector<user_record>*>(possible_vector);

        // Expecting ID, NAME, PASSWORD order in select
        rows->push_back(std::make_tuple(argv[0] ? argv[0] : "",
                                       argv[1] ? argv[1] : "",
                                       argv[2] ? argv[2] : ""));
    }
    return 0;
}

// DO NOT CHANGE
static bool initialize_database(sqlite3* db)
{
    char* error_message = NULL;

    std::string sql =
        "CREATE TABLE USERS("
        "ID INT PRIMARY KEY NOT NULL,"
        "NAME TEXT NOT NULL,"
        "PASSWORD TEXT NOT NULL);";

    int result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
    if (result != SQLITE_OK)
    {
        std::cerr << "SQL error creating table: " << (error_message ? error_message : "") << std::endl;
        sqlite3_free(error_message);
        return false;
    }

    // Add a few users (intentionally terrible practice for demo: plaintext passwords)
    sql = "INSERT INTO USERS (ID,NAME,PASSWORD) VALUES (1,'Fred','flintstone');";
    result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
    if (result != SQLITE_OK)
    {
        std::cerr << "SQL error inserting: " << (error_message ? error_message : "") << std::endl;
        sqlite3_free(error_message);
        return false;
    }

    sql = "INSERT INTO USERS (ID,NAME,PASSWORD) VALUES (2,'Barney','rubble');";
    result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
    if (result != SQLITE_OK)
    {
        std::cerr << "SQL error inserting: " << (error_message ? error_message : "") << std::endl;
        sqlite3_free(error_message);
        return false;
    }

    sql = "INSERT INTO USERS (ID,NAME,PASSWORD) VALUES (3,'Wilma','slate');";
    result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
    if (result != SQLITE_OK)
    {
        std::cerr << "SQL error inserting: " << (error_message ? error_message : "") << std::endl;
        sqlite3_free(error_message);
        return false;
    }

    return true;
}

// Helper: trim whitespace (used to normalize values)
static std::string trim_copy(std::string s)
{
    auto not_space = [](unsigned char ch) { return !std::isspace(ch); };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), not_space));
    s.erase(std::find_if(s.rbegin(), s.rend(), not_space).base(), s.end());
    return s;
}

// Helper: detect ONLY the required injection pattern: OR value=value;
// value may be numeric literal or single-quoted string literal.
static bool is_or_value_equals_value_injection(const std::string& sql)
{
    // Capture: OR <literal> = <literal> [optional ;]
    // literal = 'text' OR number (int/float)
    // We then compare the two literal values for equality; only block if they match.
    static const std::regex pattern(
        R"(\bor\b\s*('([^']*)'|\d+(?:\.\d+)?)\s*=\s*('([^']*)'|\d+(?:\.\d+)?)\s*;?)",
        std::regex_constants::icase);

    std::smatch m;
    if (!std::regex_search(sql, m, pattern))
        return false;

    // m[1] = first literal (either 'text' or number)
    // m[2] = first text inside quotes (only if first literal is quoted)
    // m[3] = second literal
    // m[4] = second text inside quotes (only if second literal is quoted)

    std::string lit1 = trim_copy(m[1].str());
    std::string lit2 = trim_copy(m[3].str());

    auto normalize_literal = [](const std::string& lit) -> std::string {
        std::string t = trim_copy(lit);
        // If quoted, strip surrounding single quotes
        if (t.size() >= 2 && t.front() == '\'' && t.back() == '\'')
        {
            return t.substr(1, t.size() - 2);
        }
        return t; // numeric stays as-is
    };

    std::string v1 = normalize_literal(lit1);
    std::string v2 = normalize_literal(lit2);

    // Only block if it is exactly the "value=value" trick (same value on both sides)
    return v1 == v2;
}

// YOU MODIFY THIS FUNCTION (defensive logic implemented here)
static bool run_query(sqlite3* db, const std::string& sql, std::vector<user_record>* out_rows = nullptr)
{
    // TODO requirement: Detect "OR value=value;" injection attempts and prevent them.
    // We defend against that specific attack pattern here.
    if (is_or_value_equals_value_injection(sql))
    {
        std::cout << "[SECURITY] संभावित SQL Injection प्रयास मिला: OR value=value; पैटर्न" << std::endl;
        std::cout << "[SECURITY] Query BLOCKED (not executed)." << std::endl;
        std::cout << "[SECURITY] Attempted SQL: " << sql << std::endl << std::endl;
        return false;
    }

    char* error_message = NULL;

    // If caller wants rows, pass vector to callback; otherwise just print.
    void* callback_arg = (out_rows ? static_cast<void*>(out_rows) : NULL);

    int result = sqlite3_exec(db, sql.c_str(), callback, callback_arg, &error_message);
    if (result != SQLITE_OK)
    {
        std::cerr << "SQL error: " << (error_message ? error_message : "") << std::endl;
        sqlite3_free(error_message);
        return false;
    }

    return true;
}

int main()
{
    sqlite3* db = NULL;

    // In-memory DB for easy, repeatable testing
    int rc = sqlite3_open(":memory:", &db);
    if (rc != SQLITE_OK)
    {
        std::cerr << "Cannot open database: " << sqlite3_errmsg(db) << std::endl;
        return 1;
    }

    if (!initialize_database(db))
    {
        sqlite3_close(db);
        return 1;
    }

    std::cout << "=== Normal query (expected: one record) ===" << std::endl;
    {
        // Normal user lookup
        std::string user_input = "Fred";
        std::string sql = "SELECT ID, NAME, PASSWORD FROM USERS" + str_where + "NAME = '" + user_input + "';";
        run_query(db, sql, nullptr);
    }

    std::cout << "=== Injection attempt 1 (string literal) ===" << std::endl;
    {
        // Typical injection: closes quote then OR 'x'='x';
        // Your defense must catch OR value=value; with value being quoted string.
        std::string user_input = "Fred' OR 'x'='x';";
        std::string sql = "SELECT ID, NAME, PASSWORD FROM USERS" + str_where + "NAME = '" + user_input + "'";
        // NOTE: In this demo, user_input already includes a semicolon; we keep it as-is.
        run_query(db, sql, nullptr);
    }

    std::cout << "=== Injection attempt 2 (numeric literal) ===" << std::endl;
    {
        // Another common injection: OR 1=1;
        std::string user_input = "Fred' OR 1=1;";
        std::string sql = "SELECT ID, NAME, PASSWORD FROM USERS" + str_where + "NAME = '" + user_input + "'";
        run_query(db, sql, nullptr);
    }

    std::cout << "=== Normal query again (still works) ===" << std::endl;
    {
        std::string user_input = "Barney";
        std::string sql = "SELECT ID, NAME, PASSWORD FROM USERS" + str_where + "NAME = '" + user_input + "';";
        run_query(db, sql, nullptr);
    }

    sqlite3_close(db);
    return 0;
}
