// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>   // std::runtime_error, std::domain_error
#include <string>

// -----------------------------
// Custom exception type (derived from std::exception via std::runtime_error)
// -----------------------------
// Intent: Provide an application-specific exception that still supports what().
class CustomApplicationException : public std::runtime_error
{
public:
  explicit CustomApplicationException(const std::string& message)
    : std::runtime_error(message)
  {
  }
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception
  // Intent: Simulate an error that would otherwise crash/terminate if not handled.
  throw std::runtime_error("Standard exception thrown inside do_even_more_custom_application_logic().");

  std::cout << "Running Even More Custom Application Logic." << std::endl;
  return true;
}

void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

  try
  {
    if (do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& ex)
  {
    // Intent: Catch standard exceptions, show user-friendly output, continue program flow.
    std::cout << "[do_custom_application_logic] Caught std::exception: " << ex.what() << std::endl;
    std::cout << "[do_custom_application_logic] Continuing processing after handling exception..." << std::endl;
  }

  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main
  // Intent: Demonstrate propagating a custom domain-level failure up to main.
  throw CustomApplicationException("CustomApplicationException thrown from do_custom_application_logic().");

  std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception
  // Intent: Prevent invalid math and provide useful error detail.
  if (den == 0.0f)
  {
    throw std::domain_error("Divide by zero error in divide().");
  }

  return (num / den);
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.
  //
  // Intent: Because this function is noexcept, exceptions MUST NOT escape.
  // Catch only the specific type we throw from divide(): std::domain_error.

  float numerator = 10.0f;
  float denominator = 0.0f;

  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::domain_error& ex)
  {
    // Intent: Handle divide-by-zero cleanly without crashing.
    std::cout << "[do_division] Caught std::domain_error: " << ex.what() << std::endl;
    std::cout << "[do_division] Using safe fallback result (0.0) and continuing..." << std::endl;
    std::cout << "divide(" << numerator << ", " << denominator << ") = 0.0" << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception
  //  that wraps the whole main function, and displays a message to the console.

  try
  {
    do_division();
    do_custom_application_logic();

    std::cout << "Main completed without exceptions escaping." << std::endl;
  }
  catch (const CustomApplicationException& ex)
  {
    // Intent: Explicitly catch our custom exception type first.
    std::cout << "[main] Caught CustomApplicationException: " << ex.what() << std::endl;
  }
  catch (const std::exception& ex)
  {
    // Intent: Catch any other standard exceptions.
    std::cout << "[main] Caught std::exception: " << ex.what() << std::endl;
  }
  catch (...)
  {
    // Intent: Last-resort safety net so the app doesn't crash silently.
    std::cout << "[main] Caught an unknown (non-std) exception." << std::endl;
  }

  std::cout << "Program finished without crashing." << std::endl;
  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
