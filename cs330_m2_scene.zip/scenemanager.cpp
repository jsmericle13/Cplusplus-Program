///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp (Milestone Two — Complex Object: Ice‑Cream Cone on Pedestal)
// Builds one complex object from multiple basic shapes:
//   - Pedestal base: cylinder
//   - Cone: cone (waffle)
//   - Scoop: sphere (slightly squashed)
// Also draws a small floor and backdrop so the object is well framed.
//
// Paste this file over your project's scenemanager.cpp in:
// CS330Content/Projects/7-1_FinalProjectMilestones/...
// Then build (Release | x64) to generate the EXE for submission.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>  // scale, rotate, translate

// Uniform names
namespace {
    const char* g_ModelName        = "model";
    const char* g_ColorValueName   = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName   = "bUseTexture";
    const char* g_UseLightingName  = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes    = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  SetTransformations()
 *  Order: Scale -> RotateX -> RotateY -> RotateZ -> Translate
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 S  = glm::scale(scaleXYZ);
    glm::mat4 Rx = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1,0,0));
    glm::mat4 Ry = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0,1,0));
    glm::mat4 Rz = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0,0,1));
    glm::mat4 T  = glm::translate(positionXYZ);

    glm::mat4 model = T * Rz * Ry * Rx * S;

    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, model);
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    glm::vec4 c(r,g,b,a);
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, c);
    }
}

/***********************************************************
 *  PrepareScene()
 *  Load meshes used by the scene (one-time).
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Stage
    m_basicMeshes->LoadPlaneMesh();

    // Complex object parts
    m_basicMeshes->LoadCylinderMesh(); // pedestal
    m_basicMeshes->LoadConeMesh();     // waffle cone
    m_basicMeshes->LoadSphereMesh();   // ice‑cream scoop
}

/***********************************************************
 *  RenderScene()
 *  Draw floor & backdrop, then the complex object.
 ***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 S, P;
    float rx=0, ry=0, rz=0;

    // ---------------------------- FLOOR ----------------------------
    S = glm::vec3(8.0f, 1.0f, 6.0f);
    P = glm::vec3(0.0f, -1.20f, 0.0f);
    SetTransformations(S, 0.0f, 0.0f, 0.0f, P);
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawPlaneMesh();

    // ------------------------- BACKGROUND --------------------------
    S = glm::vec3(8.0f, 1.0f, 6.0f);
    P = glm::vec3(0.0f, 4.25f, -6.0f);
    SetTransformations(S, 90.0f, 0.0f, 0.0f, P);
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawPlaneMesh();

    // ====================== COMPLEX OBJECT =========================
    // A stylized "ice‑cream cone on a short pedestal"
    // All transforms follow SCALE -> ROTATE -> TRANSLATE

    // --- Pedestal (Cylinder) ---
    // Wider radius so the cone sits on it; medium height.
    S  = glm::vec3(1.20f, 0.50f, 1.20f);  // radius (x,z), height (y)
    rx = ry = rz = 0.0f;
    P  = glm::vec3(0.0f, -0.70f, -1.2f);
    SetTransformations(S, rx, ry, rz, P);
    SetShaderColor(0.40f, 0.55f, 0.95f, 1.0f);  // blue pedestal
    m_basicMeshes->DrawCylinderMesh();

    // --- Waffle Cone (Cone) ---
    // Pointing up, centered on top of pedestal.
    S  = glm::vec3(0.75f, 1.30f, 0.75f);
    rx = 0.0f; ry = 0.0f; rz = 0.0f;
    P  = glm::vec3(0.0f, 0.70f, -1.2f);
    SetTransformations(S, rx, ry, rz, P);
    SetShaderColor(0.90f, 0.75f, 0.45f, 1.0f);  // waffle brown
    m_basicMeshes->DrawConeMesh();

    // --- Scoop (Sphere) ---
    // Slightly squashed so it looks seated onto the cone rim.
    S  = glm::vec3(0.85f, 0.75f, 0.85f);
    rx = ry = rz = 0.0f;
    P  = glm::vec3(0.0f, 1.70f, -1.0f);  // a hair toward camera for readability
    SetTransformations(S, rx, ry, rz, P);
    SetShaderColor(0.93f, 0.55f, 0.88f, 1.0f);  // strawberry/violet
    m_basicMeshes->DrawSphereMesh();

    // ---------------------- tweak guidance ----------------------
    // If anything sinks/floats, adjust its Y:
    //   Pedestal P.y, Cone P.y, Scoop P.y by ±0.05f–0.15f.
    // If camera differs, nudge all Z around -1.2f closer/farther.
}
