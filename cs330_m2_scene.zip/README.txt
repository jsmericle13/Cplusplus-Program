
CS 330 Milestone Two — Complex Object (Ice‑Cream Cone on Pedestal)
==================================================================

Files included:
- scenemanager.cpp  → drop-in replacement for your project file.

How to use:
1) Open the milestone project:
   CS330Content/Projects/7-1_FinalProjectMilestones
2) Replace the existing `scenemanager.cpp` with the one in this zip.
3) Build **Release | x64** to produce the EXE for submission.
4) Run to verify: you should see a cone + scoop on a blue pedestal with a floor and backdrop.

Notes:
- Uses only basic meshes available in the template (Plane, Cylinder, Cone, Sphere).
- All transforms follow SCALE → ROTATE → TRANSLATE (as the rubric requests).
- If any piece clips: adjust the Y of the part by ±0.05 in `RenderScene()`.
