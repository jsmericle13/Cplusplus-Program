(function () {
  'use strict';

  angular.module('travlrAdmin', ['ngRoute'])
    .config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {
      $routeProvider
        .when('/login', { templateUrl: '/admin/views/login.html', controller: 'LoginCtrl', controllerAs: 'vm' })
        .when('/trips', { templateUrl: '/admin/views/trips.html', controller: 'TripsCtrl', controllerAs: 'vm' })
        .when('/users', { templateUrl: '/admin/views/users.html', controller: 'UsersCtrl', controllerAs: 'vm' })
        .otherwise({ redirectTo: '/login' });

      // Attach auth token to API calls
      $httpProvider.interceptors.push(['AuthService', function (AuthService) {
        return {
          request: function (config) {
            if (config.url.indexOf('/api/') === 0) {
              const token = AuthService.getToken();
              if (token) config.headers.Authorization = 'Bearer ' + token;
            }
            return config;
          }
        };
      }]);
    }])
    .run(['$rootScope', '$location', 'AuthService', function ($rootScope, $location, AuthService) {
      $rootScope.globalMessage = '';

      $rootScope.$on('$routeChangeStart', function (evt, next) {
        const isLogin = next && next.originalPath === '/login';
        if (!isLogin && !AuthService.isAuthed()) {
          evt.preventDefault();
          $location.path('/login');
        }
      });
    }]);
})();
