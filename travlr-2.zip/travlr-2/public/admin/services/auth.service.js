(function () {
  'use strict';

  angular.module('travlrAdmin')
    .factory('AuthService', ['$window', function ($window) {
      const KEY = 'travlr_token';

      function setToken(token) {
        $window.localStorage.setItem(KEY, token);
      }

      function getToken() {
        return $window.localStorage.getItem(KEY) || '';
      }

      function clearToken() {
        $window.localStorage.removeItem(KEY);
      }

      function isAuthed() {
        return !!getToken();
      }

      return { setToken, getToken, clearToken, isAuthed };
    }]);
})();
