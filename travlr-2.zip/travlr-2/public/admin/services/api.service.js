(function () {
  'use strict';

  angular.module('travlrAdmin')
    .factory('ApiService', ['$http', function ($http) {
      function login(username, password) {
        return $http.post('/api/login', { username, password });
      }

      function listTrips() {
        return $http.get('/api/trips');
      }

      function createTrip(trip) {
        return $http.post('/api/trips', trip);
      }

      function updateTrip(code, trip) {
        return $http.put('/api/trips/' + encodeURIComponent(code), trip);
      }

      function deleteTrip(code) {
        return $http.delete('/api/trips/' + encodeURIComponent(code));
      }

      function listUsers() {
        return $http.get('/api/users');
      }

      return { login, listTrips, createTrip, updateTrip, deleteTrip, listUsers };
    }]);
})();
