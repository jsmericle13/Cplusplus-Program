(function () {
  'use strict';

  angular.module('travlrAdmin')
    .controller('NavCtrl', ['$location', 'AuthService', function ($location, AuthService) {
      const vm = this;

      vm.isAuthed = function () {
        return AuthService.isAuthed();
      };

      vm.logout = function () {
        AuthService.clearToken();
        $location.path('/login');
      };
    }]);
})();
