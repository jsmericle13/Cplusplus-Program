(function () {
  'use strict';

  angular.module('travlrAdmin')
    .controller('TripsCtrl', ['$rootScope', 'ApiService', function ($rootScope, ApiService) {
      const vm = this;

      vm.trips = [];
      vm.loading = false;
      vm.error = '';

      vm.newTrip = {
        code: '',
        name: '',
        length: 1,
        start: '',
        resort: '',
        perPerson: 0,
        image: '',
        description: ''
      };

      vm.editing = null; // trip code

      vm.load = function () {
        vm.loading = true;
        vm.error = '';
        ApiService.listTrips()
          .then(function (resp) {
            vm.trips = resp.data || [];
          })
          .catch(function () {
            vm.error = 'Could not load trips';
          })
          .finally(function () {
            vm.loading = false;
          });
      };

      vm.startEdit = function (trip) {
        vm.editing = trip.code;
        vm.editTrip = angular.copy(trip);
        // Make date input compatible with YYYY-MM-DD
        if (vm.editTrip.start) vm.editTrip.start = new Date(vm.editTrip.start).toISOString().slice(0, 10);
      };

      vm.cancelEdit = function () {
        vm.editing = null;
        vm.editTrip = null;
      };

      vm.create = function () {
        vm.error = '';
        $rootScope.globalMessage = '';

        const payload = angular.copy(vm.newTrip);
        if (payload.start) payload.start = new Date(payload.start);

        ApiService.createTrip(payload)
          .then(function () {
            $rootScope.globalMessage = 'Trip created.';
            vm.newTrip = { code:'', name:'', length:1, start:'', resort:'', perPerson:0, image:'', description:'' };
            vm.load();
          })
          .catch(function (err) {
            vm.error = (err.data && err.data.message) ? err.data.message : 'Create failed';
          });
      };

      vm.save = function () {
        vm.error = '';
        $rootScope.globalMessage = '';

        const code = vm.editTrip.code;
        const payload = angular.copy(vm.editTrip);
        if (payload.start) payload.start = new Date(payload.start);

        ApiService.updateTrip(code, payload)
          .then(function () {
            $rootScope.globalMessage = 'Trip updated.';
            vm.cancelEdit();
            vm.load();
          })
          .catch(function (err) {
            vm.error = (err.data && err.data.message) ? err.data.message : 'Update failed';
          });
      };

      vm.remove = function (trip) {
        vm.error = '';
        $rootScope.globalMessage = '';

        if (!confirm('Delete trip ' + trip.code + '?')) return;

        ApiService.deleteTrip(trip.code)
          .then(function () {
            $rootScope.globalMessage = 'Trip deleted.';
            vm.load();
          })
          .catch(function (err) {
            vm.error = (err.data && err.data.message) ? err.data.message : 'Delete failed';
          });
      };

      vm.load();
    }]);
})();
