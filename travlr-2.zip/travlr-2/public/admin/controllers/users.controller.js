(function () {
  'use strict';

  angular.module('travlrAdmin')
    .controller('UsersCtrl', ['ApiService', function (ApiService) {
      const vm = this;
      vm.users = [];
      vm.error = '';
      vm.loading = false;

      vm.load = function () {
        vm.loading = true;
        vm.error = '';
        ApiService.listUsers()
          .then(function (resp) {
            vm.users = resp.data || [];
          })
          .catch(function () {
            vm.error = 'Could not load users';
          })
          .finally(function () {
            vm.loading = false;
          });
      };

      vm.load();
    }]);
})();
