(function () {
  'use strict';

  angular.module('travlrAdmin')
    .controller('LoginCtrl', ['$location', '$rootScope', 'ApiService', 'AuthService', function ($location, $rootScope, ApiService, AuthService) {
      const vm = this;
      vm.form = { username: 'admin', password: 'password123!' };
      vm.error = '';

      vm.submit = function () {
        vm.error = '';
        $rootScope.globalMessage = '';

        ApiService.login(vm.form.username, vm.form.password)
          .then(function (resp) {
            AuthService.setToken(resp.data.token);
            $location.path('/trips');
          })
          .catch(function (err) {
            vm.error = (err.data && err.data.message) ? err.data.message : 'Login failed';
          });
      };
    }]);
})();
