# Travlr (CS 465 Module 4)

- MVC with Express routes, controllers, and Handlebars views.
- MongoDB + Mongoose API for trips at `/api/trips` and `/api/trips/:tripCode`.
- Start: `npm install` then `npm run dev` and open `http://localhost:3000/travel`.

## Database

- Default MongoDB connection string: `mongodb://127.0.0.1/travlr`.
- Seed data is provided in `trips.json`.
- To import seed data (from the project root), you can run, for example:

  ```bash
  mongoimport --db travlr --collection trips --file trips.json --jsonArray
  ```

- You can verify the data in MongoDB Compass or `mongosh`, and test the API using a browser or tool like Postman:
  - `GET http://localhost:3000/api/trips`
  - `GET http://localhost:3000/api/trips/BALI01`


## Module Seven / Final Project Notes

### Run
```bash
npm install
npm run dev
```

Customer site:
- http://localhost:3000/travel

Admin SPA:
- http://localhost:3000/admin

### Default Admin Login (seeded on first run)
- Username: `admin`
- Password: `password123!`

You can override these with environment variables:
- `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `ADMIN_EMAIL`, and `JWT_SECRET`
