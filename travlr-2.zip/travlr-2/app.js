const path = require('path');
const express = require('express');
const logger = require('morgan');
const hbs = require('hbs');

const travelerRouter = require('./app_server/routes/traveler');
const apiRouter = require('./app_api/routes');

// Initialize database connection and models
require('./app_api/models/db');

const app = express();

// ----- Middleware configuration -----
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Static assets (CSS, client-side JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// Admin SPA (AngularJS)
app.use('/admin', express.static(path.join(__dirname, 'public', 'admin')));
app.get('/admin', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'admin', 'index.html'))
);
app.get('/admin/*', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'admin', 'index.html'))
);

// ----- View engine configuration -----
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// Register partials (header, footer, etc.)
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

// ----- Routes -----
// Server-side rendered pages (customer-facing)
app.use('/travel', travelerRouter);

// RESTful API endpoints (backend for SPA)
app.use('/api', apiRouter);

// Redirect root to /travel for convenience
app.get('/', (req, res) => res.redirect('/travel'));

// Catch-all 404 handler
app.use((req, res) => {
  // Return JSON for missing API routes
  if (req.originalUrl.startsWith('/api/')) {
    return res.status(404).json({ message: 'Not Found' });
  }

  return res.status(404).render('index', {
    title: 'Not Found',
    lead: 'Page not found'
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/travel`);
});

module.exports = app;
