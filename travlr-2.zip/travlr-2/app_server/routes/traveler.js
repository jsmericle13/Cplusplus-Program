const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/traveler');

router.get('/', ctrl.home);
router.get('/about', ctrl.about);
router.get('/trips', ctrl.trips);

module.exports = router;
