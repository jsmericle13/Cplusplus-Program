const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

function mapTripForView(t) {
  return {
    code: t.code,
    name: t.name,
    nights: t.length,
    price: t.perPerson,
    start: t.start,
    resort: t.resort,
    description: t.description,
    image: t.image
  };
}

module.exports = {
  async home(req, res) {
    try {
      const trips = await Trip.find({}).sort({ start: 1 }).limit(3).exec();
      res.render('index', {
        title: 'Travlr | Home',
        lead: 'Plan your next adventure.',
        trips: trips.map(mapTripForView)
      });
    } catch (err) {
      res.render('index', {
        title: 'Travlr | Home',
        lead: 'Plan your next adventure.',
        trips: []
      });
    }
  },

  about(req, res) {
    res.render('about', {
      title: 'About Travlr',
      content: 'Travlr Getaways helps you discover and book curated trips around the world.'
    });
  },

  async trips(req, res) {
    const q = (req.query.q || '').trim();
    const minPrice = req.query.minPrice ? Number(req.query.minPrice) : null;
    const maxPrice = req.query.maxPrice ? Number(req.query.maxPrice) : null;

    const filter = {};
    if (!Number.isNaN(minPrice) && minPrice !== null) filter.perPerson = { ...(filter.perPerson || {}), $gte: minPrice };
    if (!Number.isNaN(maxPrice) && maxPrice !== null) filter.perPerson = { ...(filter.perPerson || {}), $lte: maxPrice };

    const textFilter = q
      ? {
          $or: [
            { name: new RegExp(q, 'i') },
            { resort: new RegExp(q, 'i') },
            { description: new RegExp(q, 'i') }
          ]
        }
      : {};

    try {
      const trips = await Trip.find({ ...filter, ...textFilter }).sort({ start: 1 }).exec();
      res.render('trips', {
        title: 'All Trips',
        trips: trips.map(mapTripForView),
        search: { q, minPrice: req.query.minPrice || '', maxPrice: req.query.maxPrice || '' }
      });
    } catch (err) {
      res.render('trips', { title: 'All Trips', trips: [], search: { q, minPrice: '', maxPrice: '' } });
    }
  }
};
