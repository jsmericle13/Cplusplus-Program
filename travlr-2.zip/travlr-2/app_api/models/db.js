const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

let dbURI = 'mongodb://127.0.0.1/travlr';

if (process.env.NODE_ENV === 'production' && process.env.MONGODB_URI) {
  dbURI = process.env.MONGODB_URI;
}

mongoose.connect(dbURI);

// Bring in the models
require('./trips');
require('./users');

mongoose.connection.on('connected', async () => {
  console.log(`Mongoose connected to ${dbURI}`);

  // Seed trips and a default admin user for testing if the database is empty.
  try {
    const Trip = mongoose.model('Trip');
    const User = mongoose.model('User');

    const tripCount = await Trip.countDocuments({});
    if (tripCount === 0) {
      const seedPath = path.join(__dirname, '..', '..', 'trips.json');
      const seedTrips = JSON.parse(fs.readFileSync(seedPath, 'utf-8'));
      await Trip.insertMany(seedTrips);
      console.log(`Seeded ${seedTrips.length} trips from trips.json`);
    }

    const adminUsername = process.env.ADMIN_USERNAME || 'admin';
    const adminPassword = process.env.ADMIN_PASSWORD || 'password123!';

    const existingAdmin = await User.findOne({ username: adminUsername }).exec();
    if (!existingAdmin) {
      const admin = new User({
        username: adminUsername,
        email: process.env.ADMIN_EMAIL || '',
        isAdmin: true,
        passwordHash: 'temp'
      });
      await admin.setPassword(adminPassword);
      await admin.save();
      console.log(`Seeded admin user '${adminUsername}'`);
    }
  } catch (err) {
    console.log('Seed error:', err);
  }
});

mongoose.connection.on('error', err => {
  console.log('Mongoose connection error:', err);
});

mongoose.connection.on('disconnected', () => {
  console.log('Mongoose disconnected');
});

const gracefulShutdown = (msg, callback) => {
  mongoose.connection.close(() => {
    console.log(`Mongoose disconnected through ${msg}`);
    callback();
  });
};

// For nodemon restarts
process.once('SIGUSR2', () => {
  gracefulShutdown('nodemon restart', () => {
    process.kill(process.pid, 'SIGUSR2');
  });
});

// For app termination
process.on('SIGINT', () => {
  gracefulShutdown('app termination', () => {
    process.exit(0);
  });
});

// For Heroku app termination
process.on('SIGTERM', () => {
  gracefulShutdown('Heroku app shutdown', () => {
    process.exit(0);
  });
});
