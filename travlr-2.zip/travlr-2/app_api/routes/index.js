const express = require('express');
const router = express.Router();

const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/auth');
const ctrlUsers = require('../controllers/users');
const { requireAuth, requireAdmin } = require('../middleware/auth');

// Auth
router.post('/register', ctrlAuth.register);
router.post('/login', ctrlAuth.login);

// Trips (public read)
router.get('/trips', ctrlTrips.tripsList);
router.get('/trips/:tripCode', ctrlTrips.tripsFindByCode);

// Trips (admin write)
router.post('/trips', requireAuth, requireAdmin, ctrlTrips.tripsAddTrip);
router.put('/trips/:tripCode', requireAuth, requireAdmin, ctrlTrips.tripsUpdateTrip);
router.delete('/trips/:tripCode', requireAuth, requireAdmin, ctrlTrips.tripsDeleteTrip);

// Users (admin)
router.get('/users', requireAuth, requireAdmin, ctrlUsers.usersList);

module.exports = router;
