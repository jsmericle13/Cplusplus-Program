const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../middleware/auth');

const User = mongoose.model('User');

function signToken(user) {
  // Keep token small: only what you need for authorization decisions.
  const payload = {
    sub: user._id.toString(),
    username: user.username,
    isAdmin: !!user.isAdmin
  };

  return jwt.sign(payload, JWT_SECRET, { expiresIn: '2h' });
}

const register = async (req, res) => {
  const { username, password, email, isAdmin } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ message: 'username and password are required' });
  }

  try {
    const existing = await User.findOne({ username }).exec();
    if (existing) {
      return res.status(409).json({ message: 'username already exists' });
    }

    const user = new User({
      username,
      email: email || '',
      isAdmin: !!isAdmin,
      passwordHash: 'temp'
    });

    await user.setPassword(password);
    await user.save();

    return res.status(201).json({
      message: 'user created',
      token: signToken(user),
      user: { username: user.username, email: user.email, isAdmin: user.isAdmin }
    });
  } catch (err) {
    return res.status(500).json({ message: 'error creating user', error: err });
  }
};

const login = async (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ message: 'username and password are required' });
  }

  try {
    const user = await User.findOne({ username }).exec();
    if (!user) {
      return res.status(401).json({ message: 'invalid credentials' });
    }

    const ok = await user.validatePassword(password);
    if (!ok) {
      return res.status(401).json({ message: 'invalid credentials' });
    }

    return res.status(200).json({
      token: signToken(user),
      user: { username: user.username, email: user.email, isAdmin: user.isAdmin }
    });
  } catch (err) {
    return res.status(500).json({ message: 'error logging in', error: err });
  }
};

module.exports = { register, login };
