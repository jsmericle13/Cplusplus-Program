const mongoose = require('mongoose');
const User = mongoose.model('User');

// GET /api/users (admin)
const usersList = async (req, res) => {
  try {
    const users = await User.find({}, { passwordHash: 0 }).sort({ createdAt: -1 }).exec();
    return res.status(200).json(users);
  } catch (err) {
    return res.status(500).json({ message: 'error retrieving users', error: err });
  }
};

module.exports = { usersList };
