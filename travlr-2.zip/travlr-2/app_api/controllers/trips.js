const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

/**
 * GET /api/trips
 * Return a JSON array of all trips.
 */
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).exec();
    return res.status(200).json(trips);
  } catch (err) {
    console.error('Error fetching trips:', err);
    return res
      .status(500)
      .json({ message: 'Error retrieving trips', error: err });
  }
};

/**
 * GET /api/trips/:tripCode
 * Return a single trip by its unique code.
 */
const tripsFindByCode = async (req, res) => {
  const { tripCode } = req.params;

  if (!tripCode) {
    return res
      .status(400)
      .json({ message: 'tripCode parameter is required' });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode.toUpperCase() }).exec();

    if (!trip) {
      return res
        .status(404)
        .json({ message: `Trip with code ${tripCode} not found` });
    }

    return res.status(200).json(trip);
  } catch (err) {
    console.error('Error fetching trip by code:', err);
    return res
      .status(500)
      .json({ message: 'Error retrieving trip', error: err });
  }
};

/**
 * POST /api/trips
 * Create a new trip in the database.
 */
const tripsAddTrip = async (req, res) => {
  try {
    const tripData = {
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    };

    const trip = await Trip.create(tripData);
    return res.status(201).json(trip);
  } catch (err) {
    console.error('Error creating trip:', err);
    return res
      .status(400)
      .json({ message: 'Error creating trip', error: err });
  }
};

/**
 * PUT /api/trips/:tripCode
 * Update an existing trip by its code.
 */
const tripsUpdateTrip = async (req, res) => {
  const { tripCode } = req.params;

  if (!tripCode) {
    return res
      .status(400)
      .json({ message: 'tripCode parameter is required' });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode.toUpperCase() }).exec();

    if (!trip) {
      return res
        .status(404)
        .json({ message: `Trip with code ${tripCode} not found` });
    }

    // Update allowed fields
    trip.name        = req.body.name        ?? trip.name;
    trip.length      = req.body.length      ?? trip.length;
    trip.start       = req.body.start       ?? trip.start;
    trip.resort      = req.body.resort      ?? trip.resort;
    trip.perPerson   = req.body.perPerson   ?? trip.perPerson;
    trip.image       = req.body.image       ?? trip.image;
    trip.description = req.body.description ?? trip.description;

    const updatedTrip = await trip.save();
    return res.status(200).json(updatedTrip);
  } catch (err) {
    console.error('Error updating trip:', err);
    return res
      .status(400)
      .json({ message: 'Error updating trip', error: err });
  }
};

/**
 * DELETE /api/trips/:tripCode
 * Remove an existing trip by its code.
 */
const tripsDeleteTrip = async (req, res) => {
  const { tripCode } = req.params;

  if (!tripCode) {
    return res
      .status(400)
      .json({ message: 'tripCode parameter is required' });
  }

  try {
    const trip = await Trip.findOneAndDelete({
      code: tripCode.toUpperCase()
    }).exec();

    if (!trip) {
      return res
        .status(404)
        .json({ message: `Trip with code ${tripCode} not found` });
    }

    return res
      .status(200)
      .json({ message: 'Trip deleted successfully', trip });
  } catch (err) {
    console.error('Error deleting trip:', err);
    return res
      .status(400)
      .json({ message: 'Error deleting trip', error: err });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};
