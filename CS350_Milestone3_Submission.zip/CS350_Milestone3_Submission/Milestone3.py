#!/usr/bin/env python3
"""
CS 350 - Milestone Three: Input With Buttons (Morse Code LEDs + LCD)

Hardware assumptions (matches the lab guide text you pasted):
- Red LED on GPIO 18 (DOT)
- Blue LED on GPIO 23 (DASH)
- Button on GPIO 24 (active-low when pressed; external pull-up via 10K resistor)

Behavior requirements:
- Blink Morse code indefinitely.
- Button press queues the next message but does NOT interrupt the current pass.
- Uses a simple state-machine style runner (states + transitions) to step through
  DOT / DASH / gaps with the required timings.
- Updates a 16x2 LCD with what is being sent (and optional debug status).
- Exits gracefully with GPIO cleanup on Ctrl+C.

Run (needs sudo for GPIO):
  sudo python3 Milestone3.py
"""

import time
import threading
from enum import Enum, auto

# ---------- GPIO (Raspberry Pi) ----------
try:
    import RPi.GPIO as GPIO
except ImportError:
    GPIO = None  # lets the file be opened/graded on non-Pi systems

# ---------- LCD (Adafruit CharLCD) ----------
# These pins match the common 4-bit wiring used in the CS 350 Module Four LCD guide:
# RS=GPIO17, EN=GPIO27, D4=GPIO5, D5=GPIO6, D6=GPIO13, D7=GPIO26
def init_lcd():
    try:
        import board
        import digitalio
        from adafruit_character_lcd.character_lcd import Character_LCD_Mono

        lcd_rs = digitalio.DigitalInOut(board.D17)
        lcd_en = digitalio.DigitalInOut(board.D27)
        lcd_d4 = digitalio.DigitalInOut(board.D5)
        lcd_d5 = digitalio.DigitalInOut(board.D6)
        lcd_d6 = digitalio.DigitalInOut(board.D13)
        lcd_d7 = digitalio.DigitalInOut(board.D26)

        lcd = Character_LCD_Mono(lcd_rs, lcd_en, lcd_d4, lcd_d5, lcd_d6, lcd_d7, 16, 2)
        lcd.clear()
        return lcd
    except Exception:
        return None


# ---------- Timings (ms -> seconds) ----------
DOT_S = 0.500
DASH_S = 1.500
SYMBOL_GAP_S = 0.250
LETTER_GAP_S = 0.750
WORD_GAP_S = 3.000

# ---------- Pins ----------
RED_LED_PIN = 18
BLUE_LED_PIN = 23
BUTTON_PIN = 24

# ---------- Morse map ----------
MORSE = {
    "A": ".-",    "B": "-...",  "C": "-.-.",  "D": "-..",   "E": ".",
    "F": "..-.",  "G": "--.",   "H": "....",  "I": "..",    "J": ".---",
    "K": "-.-",   "L": ".-..",  "M": "--",    "N": "-.",    "O": "---",
    "P": ".--.",  "Q": "--.-",  "R": ".-.",   "S": "...",   "T": "-",
    "U": "..-",   "V": "...-",  "W": ".--",   "X": "-..-",  "Y": "-.--",
    "Z": "--..",
    "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-",
    "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",
}

# Messages to cycle through on each button press
MESSAGES = [
    "SOS",
    "HELLO WORLD",
]


class State(Enum):
    OFF = auto()
    DOT_ON = auto()
    DASH_ON = auto()
    SYMBOL_GAP = auto()
    LETTER_GAP = auto()
    WORD_GAP = auto()


class MorseController:
    def __init__(self, debug: bool = True):
        self.debug = debug
        self._stop = threading.Event()

        # message switching (button press queues next message)
        self._lock = threading.Lock()
        self._msg_index = 0
        self._queued_index = None  # None means no change queued

        self.state = State.OFF
        self.lcd = init_lcd()

        # GPIO setup
        self._gpio_ready = GPIO is not None
        if self._gpio_ready:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)

            GPIO.setup(RED_LED_PIN, GPIO.OUT, initial=GPIO.LOW)
            GPIO.setup(BLUE_LED_PIN, GPIO.OUT, initial=GPIO.LOW)

            # Button: active-low press (pressed -> LOW)
            GPIO.setup(BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

            GPIO.add_event_detect(
                BUTTON_PIN,
                GPIO.FALLING,
                callback=self._on_button_pressed,
                bouncetime=200,
            )

    # ---------------- Button ----------------
    def _on_button_pressed(self, channel):
        with self._lock:
            next_index = (self._msg_index + 1) % len(MESSAGES)
            self._queued_index = next_index
            if self.debug:
                print(f"[BTN] Press detected -> queued message: {MESSAGES[next_index]!r}")

        # quick LCD feedback (doesn't change current message mid-pass)
        self._lcd_write(
            line1=f"QUEUED:",
            line2=MESSAGES[next_index][:16],
        )

    # ---------------- LCD helpers ----------------
    def _lcd_write(self, line1: str = "", line2: str = ""):
        if self.lcd is None:
            return
        line1 = (line1 or "")[:16].ljust(16)
        line2 = (line2 or "")[:16].ljust(16)
        try:
            self.lcd.message = f"{line1}\n{line2}"
        except Exception:
            # ignore LCD errors during runtime
            pass

    # ---------------- GPIO helpers ----------------
    def _all_off(self):
        if not self._gpio_ready:
            return
        GPIO.output(RED_LED_PIN, GPIO.LOW)
        GPIO.output(BLUE_LED_PIN, GPIO.LOW)

    def _dot_on(self):
        if not self._gpio_ready:
            return
        GPIO.output(RED_LED_PIN, GPIO.HIGH)
        GPIO.output(BLUE_LED_PIN, GPIO.LOW)

    def _dash_on(self):
        if not self._gpio_ready:
            return
        GPIO.output(RED_LED_PIN, GPIO.LOW)
        GPIO.output(BLUE_LED_PIN, GPIO.HIGH)

    # ---------------- State machine runner ----------------
    def _build_actions_for_message(self, msg: str):
        """
        Convert a message into a list of (State, duration_seconds) actions.
        LEDs:
          - DOT uses red LED
          - DASH uses blue LED
          - OFF state used for all gaps
        """
        msg = msg.upper()
        actions = []

        words = msg.split(" ")
        for w_i, word in enumerate(words):
            for c_i, ch in enumerate(word):
                code = MORSE.get(ch, "")
                # Skip unknown chars but keep spacing behavior reasonably
                if not code:
                    continue

                for s_i, symbol in enumerate(code):
                    if symbol == ".":
                        actions.append((State.DOT_ON, DOT_S))
                    elif symbol == "-":
                        actions.append((State.DASH_ON, DASH_S))

                    # gap between symbols inside a letter
                    if s_i != len(code) - 1:
                        actions.append((State.SYMBOL_GAP, SYMBOL_GAP_S))

                # gap between letters (but not after the last letter in the word)
                if c_i != len(word) - 1:
                    actions.append((State.LETTER_GAP, LETTER_GAP_S))

            # gap between words (but not after last word)
            if w_i != len(words) - 1:
                actions.append((State.WORD_GAP, WORD_GAP_S))

        return actions

    def _apply_state(self, state: State):
        self.state = state
        if state == State.OFF:
            self._all_off()
        elif state == State.DOT_ON:
            self._dot_on()
        elif state == State.DASH_ON:
            self._dash_on()
        else:
            # gaps are OFF
            self._all_off()

    def run(self):
        """
        Starts the blinking loop in a separate thread so button presses can be
        detected and queued without interrupting the current pass.
        """
        worker = threading.Thread(target=self._blink_loop, daemon=True)
        worker.start()

        try:
            while not self._stop.is_set():
                time.sleep(0.1)
        except KeyboardInterrupt:
            print("\n[EXIT] KeyboardInterrupt received.")
        finally:
            self.stop()
            worker.join(timeout=2.0)

    def _blink_loop(self):
        while not self._stop.is_set():
            # snapshot current message at the start of each pass
            with self._lock:
                msg = MESSAGES[self._msg_index]
                queued = self._queued_index

            # update LCD at the start of a pass
            self._lcd_write("SENDING:", msg[:16])

            actions = self._build_actions_for_message(msg)

            if self.debug:
                print(f"[MSG] Sending: {msg!r} (actions={len(actions)})")

            for (state, duration) in actions:
                if self._stop.is_set():
                    break

                self._apply_state(state)
                if self.debug:
                    print(f"[STATE] {state.name} for {duration:.3f}s")
                time.sleep(duration)

                # always return to OFF after each action
                self._apply_state(State.OFF)

            # end-of-pass: apply queued message change (if any)
            with self._lock:
                if self._queued_index is not None:
                    self._msg_index = self._queued_index
                    self._queued_index = None

                    # show what will be sent next
                    new_msg = MESSAGES[self._msg_index]
                    if self.debug:
                        print(f"[MSG] Switched to next message: {new_msg!r}")
                    self._lcd_write("NEXT MSG:", new_msg[:16])

            # tiny pause so transitions look clean
            time.sleep(0.1)

    def stop(self):
        self._stop.set()
        self._apply_state(State.OFF)
        if self.lcd is not None:
            try:
                self.lcd.clear()
            except Exception:
                pass
        if self._gpio_ready:
            try:
                GPIO.cleanup()
            except Exception:
                pass


def main():
    controller = MorseController(debug=True)
    controller.run()


if __name__ == "__main__":
    main()
