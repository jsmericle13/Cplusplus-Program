CS 350 Milestone Three - Submission Pack

Files included:
- Milestone3.py
- Milestone3_LabQuestions.docx
- StateMachineDiagram.pdf
- VIDEO_INSTRUCTIONS.txt

How to run (on Raspberry Pi):
1) Install the required packages:
   sudo pip3 install python-statemachine
   (LCD libs if needed: adafruit-blinka, adafruit-circuitpython-charlcd)

2) Run:
   sudo python3 Milestone3.py
