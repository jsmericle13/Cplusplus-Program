// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

#include <stdexcept>  // std::out_of_range

//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0u);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
// TEST_F(CollectionTest, AlwaysFail)
// {
//   FAIL();
// }

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // Start condition: empty
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0u);

  add_entries(1);

  // End condition: not empty, size == 1
  ASSERT_FALSE(collection->empty());
  ASSERT_EQ(collection->size(), 1u);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  ASSERT_TRUE(collection->empty());
  add_entries(5);

  ASSERT_FALSE(collection->empty());
  ASSERT_EQ(collection->size(), 5u);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSizeFor0_1_5_10)
{
  // 0 entries
  ASSERT_EQ(collection->size(), 0u);
  EXPECT_GE(collection->max_size(), collection->size());

  // 1 entry
  add_entries(1);
  EXPECT_GE(collection->max_size(), collection->size());

  // 5 entries
  collection->clear();
  add_entries(5);
  EXPECT_GE(collection->max_size(), collection->size());

  // 10 entries
  collection->clear();
  add_entries(10);
  EXPECT_GE(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSizeFor0_1_5_10)
{
  // 0 entries
  ASSERT_EQ(collection->size(), 0u);
  EXPECT_GE(collection->capacity(), collection->size());

  // 1 entry
  add_entries(1);
  EXPECT_GE(collection->capacity(), collection->size());

  // 5 entries
  collection->clear();
  add_entries(5);
  EXPECT_GE(collection->capacity(), collection->size());

  // 10 entries
  collection->clear();
  add_entries(10);
  EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesTheCollection)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5u);

  // Resize up should increase size
  collection->resize(10);

  ASSERT_EQ(collection->size(), 10u);
  EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesTheCollection)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10u);

  // Resize down should decrease size
  collection->resize(5);

  ASSERT_EQ(collection->size(), 5u);
  EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesTheCollectionToZero)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10u);

  collection->resize(0);

  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0u);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesTheCollection)
{
  add_entries(10);
  ASSERT_FALSE(collection->empty());

  collection->clear();

  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0u);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginToEndErasesTheCollection)
{
  add_entries(10);
  ASSERT_EQ(collection->size(), 10u);

  // erase(begin, end) should remove all elements
  collection->erase(collection->begin(), collection->end());

  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0u);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
  add_entries(5);
  const auto originalSize = collection->size();
  const auto originalCap = collection->capacity();

  // reserve should not change size, only capacity (if requested > current capacity)
  collection->reserve(originalCap + 50);

  EXPECT_EQ(collection->size(), originalSize);
  EXPECT_GE(collection->capacity(), originalCap + 50);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexIsOutOfBounds)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5u);

  // Valid indices are [0..size-1], so index == size is out-of-range
  EXPECT_THROW(collection->at(collection->size()), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// Custom positive: push_back grows size and back() returns the correct value
TEST_F(CollectionTest, PushBackIncreasesSizeAndBackMatchesValue)
{
  ASSERT_TRUE(collection->empty());

  collection->push_back(42);

  ASSERT_EQ(collection->size(), 1u);
  EXPECT_EQ(collection->back(), 42);
}

// Custom negative: at(0) on empty vector throws out_of_range
TEST_F(CollectionTest, AtThrowsOutOfRangeOnEmptyVector)
{
  ASSERT_TRUE(collection->empty());
  EXPECT_THROW(collection->at(0), std::out_of_range);
}
