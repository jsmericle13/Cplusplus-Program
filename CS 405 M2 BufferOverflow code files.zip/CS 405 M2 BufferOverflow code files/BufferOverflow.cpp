// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <cctype>   // std::isspace
#include <limits>   // std::numeric_limits
#include <string>   // std::string

// Reads a single token (whitespace-delimited) safely into a fixed-size buffer.
// Returns true if the user entered more characters than the buffer can hold.
//
// This defends against buffer overflow by:
//  1) Limiting how many characters std::cin extracts into the buffer
//  2) Detecting if additional characters remained in the input stream
//  3) Clearing the error state and discarding the remaining input so later reads are safe
static bool read_token_safely(char* buffer, std::size_t buffer_size)
{
  // TODO: Prevent overflow for fixed-size buffers by limiting extraction to (size - 1)
  // so we always have room for the null terminator.
  std::cin >> std::setw(static_cast<int>(buffer_size)) >> buffer;

  // If the user typed more characters than we accepted, the next character in the
  // stream will still be part of that token (not whitespace / newline).
  bool overflow_attempt = false;
  if (std::cin.good())
  {
    int next = std::cin.peek();
    if (next != EOF && !std::isspace(static_cast<unsigned char>(next)))
    {
      overflow_attempt = true;

      // Discard the rest of the token to keep the stream usable.
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
  }
  else
  {
    // If extraction failed for some reason, clear state and discard line.
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  }

  return overflow_attempt;
}

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";

  // TODO: Read user input safely to prevent buffer overflow.
  // We also detect and report if the user attempted to enter too much data.
  bool overflow_attempt = read_token_safely(user_input, sizeof(user_input));
  if (overflow_attempt)
  {
    std::cout << "[SECURITY] Buffer overflow attempt detected: input was longer than 19 characters and was truncated." << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
